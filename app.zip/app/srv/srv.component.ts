import { Component } from '@angular/core';

@Component({
  selector: 'app-srv',
  templateUrl: './srv.component.html'
})
export class SrvComponent {

}